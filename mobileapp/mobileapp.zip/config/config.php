<?php
    define("SERVER", "localhost");
    define("DATABASE", "andjicabazicaradio");
    define("USERNAME", "root");
    define("PASSWORD", "");

    
    /*define("SERVER", "localhost");
    define("DATABASE", "andjicabazicaradio");
    define("USERNAME", "andjicabazica");
    define("PASSWORD", "andjicabazica");*/


?>